class PyLibDMTXError(Exception):
    pass
