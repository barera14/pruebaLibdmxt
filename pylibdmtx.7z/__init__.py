"""Read and write Data Matrix barcodes from Python 2 and 3."""

__version__ = '0.1.10'
